<?php
class newstudio
{
	protected static $sess_cookie;
	protected static $exucution;
	protected static $warning;

	protected static $page;
	protected static $log_page;
	protected static $xml_page;

	//проверяем cookie
	public static function checkCookie($sess_cookie)
	{
		$result = Sys::getUrlContent(
			array(
				'type'           => 'POST',
				'returntransfer' => 1,
				'follow'		 => 1,
				'url'            => 'https://newstudio.tv',
				'cookie'         => $sess_cookie,
				'sendHeader'     => array('Host' => 'newstudio.tv', 'Content-length' => strlen($sess_cookie)),
			)
		);

		if (preg_match('/login\.php\?logout=1/', $result))
			return TRUE;
		else
			return FALSE;
	}

	public static function checkRule($data)
	{
		if (preg_match('/^[\.\+\s\'\`\:\;\-a-zA-Z0-9]+$/', $data))
			return TRUE;
		else
			return FALSE;
	}

	//функция преобразования даты из строки
	private static function dateStringToNum($data)
	{
		$data = substr($data, 5);
		$data = substr($data, 0, -6);

		$monthes = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
		$month = substr($data, 3, 3);
		$data = preg_replace('/(\d\d)-(\d\d)-(\d\d)/', '$3-$2-$1', str_replace($month, str_pad(array_search($month, $monthes)+1, 2, 0, STR_PAD_LEFT), $data));

		$data = preg_split('/\s/', $data);
		$date = $data[2].'-'.$data[1].'-'.$data[0].' '.$data[3];
		return $date;
	}

	//функция преобразования даты в строку
	private static function dateNumToString($data)
	{
		$data = substr($data, 0, -3);
		$data = str_replace('-', ' ', $data);
		$arr = preg_split('/\s/', $data);

		$month = Sys::dateNumToString($arr[1]);
		$date = $arr[2].' '.$month.' '.$arr[0].' '.$arr[3];
		return $date;
	}

	//функция поиска id torrent-файла
	private static function findID($link)
	{
            $result = Sys::getUrlContent(
			array(
				'type'           => 'POST',
				'returntransfer' => 1,
				'follow'		 => 1,
				'url'            => $link,
				'cookie'         => newstudio::$sess_cookie,
				'sendHeader'     => array('Host' => 'newstudio.tv', 'Content-length' => strlen(newstudio::$sess_cookie)),
			)
		);

		if (preg_match('/download\.php\?id=(\d{2,6})/', $result, $matches))
			return $matches[1];
		else
			return FALSE;
	}

    //функция анализа эпизода
	private static function analysisEpisode($item)
	{
		preg_match('/Сезон (\d{1,2}), Серия (\d{1,2})/', $item->title, $matches);
		if (isset($matches[1]) && isset($matches[2]))
		{
		    if (strlen($matches[1]) == 1)
		        $matches[1] = '0'.$matches[1];
		    if (strlen($matches[2]) == 1)
		        $matches[2] = '0'.$matches[2];
			$episode = 'S'.$matches[1].'E'.$matches[2];
			$date = $item->pubDate;
			$downloadId = newstudio::findID((string)$item->link);
			return array('episode'=>$episode, 'date'=>$date, 'link'=>'https://newstudio.tv/download.php?id='.$downloadId);
		}
	}

	//функция анализа xml ленты
	private static function analysis($name, $hd, $item)
	{
		if (preg_match('/'.$name.'/i', (string)$item->title))
		{
			if ($hd == 1)
			{
				if (preg_match_all('/720p/', $item->title, $matches))
					return newstudio::analysisEpisode($item);
			}
			elseif ($hd == 2)
			{
				if (preg_match_all('/1080p/', $item->title, $matches))
					return newstudio::analysisEpisode($item);
			}
			else
			{
				if (preg_match_all('/WEBDLRip/', $item->title, $matches))
					return newstudio::analysisEpisode($item);
			}
		}
	}

	//функция получения кук
	public static function getCookie($tracker)
	{
		//проверяем заполнены ли учётные данные
		if (Database::checkTrackersCredentialsExist($tracker))
		{
			//получаем учётные данные
			$credentials = Database::getCredentials($tracker);
			$login = iconv('utf-8', 'windows-1251', $credentials['login']);
			$password = $credentials['password'];

			$page = Sys::getUrlContent(
            	array(
            		'type'           => 'POST',
            		'header'         => 1,
            		'returntransfer' => 1,
					'follow'		 => 1,
            		'url'            => 'https://newstudio.tv/login.php',
            		'postfields'     => 'login_username='.$login.'&login_password='.$password.'&autologin=1&login=1',
            	)
            );

			if ( ! empty($page))
			{
				//проверяем подходят ли учётные данные
				if (preg_match_all('/Cookie: (.*);/U', $page, $array))
				{
					newstudio::$sess_cookie = $array[1][0];
					Database::setCookie($tracker, newstudio::$sess_cookie);
					//запускам процесс выполнения, т.к. не может работать без кук
					newstudio::$exucution = TRUE;
				}
				//проверяем нет ли сообщения о неправильном логине/пароле
				elseif (preg_match('/profile\.php\?mode=sendpassword/', $page, $out))
				{
					//устанавливаем варнинг
					if (newstudio::$warning == NULL)
        			{
        				newstudio::$warning = TRUE;
        				Errors::setWarnings($tracker, 'credential_wrong');
        			}
					//останавливаем выполнение цепочки
					newstudio::$exucution = FALSE;
				}
				//если не удалось получить никаких данных со страницы, значит трекер не доступен
				else
				{
					//устанавливаем варнинг
					if (newstudio::$warning == NULL)
        			{
        				newstudio::$warning = TRUE;
        				Errors::setWarnings($tracker, 'cant_find_cookie');
        			}
					//останавливаем выполнение цепочки
					newstudio::$exucution = FALSE;
				}
			}
			else
			{
				//устанавливаем варнинг
				if (newstudio::$warning == NULL)
    			{
    				newstudio::$warning = TRUE;
    				Errors::setWarnings($tracker, 'cant_get_auth_page');
    			}
				//останавливаем выполнение цепочки
				newstudio::$exucution = FALSE;
			}
		}
		else
		{
			//устанавливаем варнинг
			if (newstudio::$warning == NULL)
			{
				newstudio::$warning = TRUE;
				Errors::setWarnings($tracker, 'credential_miss');
			}
			//останавливаем выполнение цепочки
			newstudio::$exucution = FALSE;
		}
	}

	//формируем параметры "проверочного" запроса для curl_multi
	//резолв куки выполняется один раз для всех строк newstudio.tv в рамках текущего прогона;
	//rss.php одинаков для каждой строки, поэтому CurlMultiFetcher схлопнёт его в один реальный запрос
	public static function getRequestParams($params)
	{
		extract($params);

		//проверяем получена ли уже кука
		if (empty(newstudio::$sess_cookie))
		{
    		$cookie = Database::getCookie($tracker);
    		if (newstudio::checkCookie($cookie))
    		{
    			newstudio::$sess_cookie = $cookie;
    			//запускам процесс выполнения
    			newstudio::$exucution = TRUE;
    		}
    		else
        		newstudio::getCookie($tracker);
		}

		if ( ! newstudio::$exucution)
			return array('url' => NULL);

		$url = 'https://newstudio.tv/rss.php';

		return array(
			'url'     => $url,
			'options' => array(CURLOPT_HTTPGET => 1) + Sys::getProxyOptions($url),
		);
	}

	//разбираем RSS-ленту (общую для всех строк newstudio.tv) и анализируем эпизоды для текущей строки
	public static function parse($params, $page)
	{
		extract($params);
		$return = NULL;

		//проверяем получена ли уже RSS лента (один раз для всех строк этого трекера)
		if (newstudio::$xml_page === NULL)
		{
			if ( ! empty($page))
			{
				//читаем xml
				$xml = @simplexml_load_string($page);
				//если XML пришёл с ошибками - останавливаем выполнение, иначе - сохраняем для остальных строк
				if ( ! $xml)
				{
					//устанавливаем варнинг
					if (newstudio::$warning == NULL)
        			{
        				newstudio::$warning = TRUE;
        				Errors::setWarnings($tracker, 'rss_parse_false');
        			}
					//останавливаем выполнение цепочки
					newstudio::$exucution = FALSE;
					newstudio::$xml_page = FALSE;
				}
				else
				{
					newstudio::$log_page = TRUE;
					newstudio::$xml_page = $xml;
				}
			}
			else
			{
				//устанавливаем варнинг
				if (newstudio::$warning == NULL)
    			{
    				newstudio::$warning = TRUE;
    				Errors::setWarnings($tracker, 'cant_find_rss');
    			}
				//останавливаем выполнение цепочки
				newstudio::$exucution = FALSE;
				newstudio::$xml_page = FALSE;
			}
		}

		//если выполнение цепочки не остановлено
		if (newstudio::$exucution)
		{
			if ( ! empty(newstudio::$xml_page))
			{
				//сбрасываем варнинг
				Database::clearWarnings($tracker);
				$nodes = array();
				foreach (newstudio::$xml_page->channel->item AS $item)
				{
				    array_unshift($nodes, $item);
				}

				foreach ($nodes as $item)
				{

					$serial = newstudio::analysis($name, $hd, $item);

					if ( ! empty($serial))
					{
						$episode = substr($serial['episode'], 4, 2);
						$season = substr($serial['episode'], 1, 2);
                        $date_str = newstudio::dateNumToString(newstudio::dateStringToNum($serial['date']));

						if ( ! empty($ep))
						{
							if ($season == substr($ep, 1, 2) && $episode > substr($ep, 4, 2))
								$download = TRUE;
							elseif ($season > substr($ep, 1, 2) && $episode < substr($ep, 4, 2))
								$download = TRUE;
							else
								$download = FALSE;
						}
						elseif ($ep == NULL)
							$download = TRUE;
						else
							$download = FALSE;

						if ($download)
						{
							$amp = ($hd) ? 'HD' : NULL;
							//сохраняем торрент в файл
							$torrent = Sys::getUrlContent(
								array(
									'type'           => 'POST',
									'returntransfer' => 1,
									'follow'		 => 1,
									'url'            => $serial['link'],
									'cookie'         => newstudio::$sess_cookie,
									'sendHeader'     => array('Host' => 'newstudio.tv', 'Content-length' => strlen(newstudio::$sess_cookie)),
								)
							);

							if (Sys::checkTorrentFile($torrent))
                            {
								$file = str_replace(' ', '.', $name).'.S'.$season.'E'.$episode.'.'.$amp;
								$episode = (substr($episode, 0, 1) == 0) ? substr($episode, 1, 1) : $episode;
								$season = (substr($season, 0, 1) == 0) ? substr($season, 1, 1) : $season;
								$message = $name.' '.$amp.' обновлён до '.$episode.' серии, '.$season.' сезона.';
                                $status = Sys::saveTorrent($tracker, $file, $torrent, $id, $hash, $message, $date_str, $name);

								//обновляем время регистрации торрента в базе
								$return[$id]['timestamp'] = newstudio::dateStringToNum($serial['date']);
								//обновляем сведения о последнем эпизоде
								$return[$id]['ep'] = $serial['episode'];
                            }
                            else
                                Errors::setWarnings($tracker, 'torrent_file_fail', $id);
						}
					}
				}
			}
		}

		return $return;
	}
}
?>
