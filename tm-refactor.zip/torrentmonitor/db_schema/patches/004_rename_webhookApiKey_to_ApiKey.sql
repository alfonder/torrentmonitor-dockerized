-- Patch 004: переименование ключа webhookApiKey -> ApiKey в таблице settings

-- MySQL / MariaDB:
UPDATE `settings` SET `key` = 'ApiKey' WHERE `key` = 'webhookApiKey';

-- SQLite:
-- UPDATE "settings" SET "key" = 'ApiKey' WHERE "key" = 'webhookApiKey';

-- PostgreSQL:
-- UPDATE settings SET "key" = 'ApiKey' WHERE "key" = 'webhookApiKey';
