-- Patch 002: увеличение длины колонки val в таблице settings до 255 символов
-- Применяется для установок, обновляющихся со старых версий (где val был varchar(100)).
-- Необходимо для сохранения длинных значений, например User-Agent строк.
-- Новые установки получают правильную длину автоматически через основные схемы.

-- MySQL / MariaDB:
ALTER TABLE `settings` MODIFY COLUMN `val` VARCHAR(255) NOT NULL DEFAULT '';

-- SQLite (не поддерживает MODIFY COLUMN, но VARCHAR(100) в SQLite фактически не ограничивает
-- длину — в SQLite типы данных не имеют жёсткого ограничения на длину строки):
-- Действий не требуется для SQLite.

-- PostgreSQL:
-- ALTER TABLE "settings" ALTER COLUMN "val" TYPE VARCHAR(255);
