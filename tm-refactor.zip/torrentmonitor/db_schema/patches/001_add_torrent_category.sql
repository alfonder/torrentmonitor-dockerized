-- Patch 001: добавление колонки category в таблицу torrent
-- Применяется для существующих установок при обновлении до версии с поддержкой категорий qBittorrent.
-- Новые установки получают колонку автоматически через основные схемы (mysql.sql / sqlite.sql / postgresql.sql).

-- MySQL / MariaDB:
ALTER TABLE `torrent` ADD COLUMN `category` VARCHAR(100) NOT NULL DEFAULT '';

-- SQLite:
-- ALTER TABLE `torrent` ADD COLUMN `category` VARCHAR(100) NOT NULL DEFAULT '';

-- PostgreSQL:
-- ALTER TABLE "torrent" ADD COLUMN "category" VARCHAR(100) NOT NULL DEFAULT '';
