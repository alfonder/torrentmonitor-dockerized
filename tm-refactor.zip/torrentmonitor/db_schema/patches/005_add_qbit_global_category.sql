INSERT INTO `settings` (`key`, `val`) VALUES ('qbitCategory', '');
-- SQLite: INSERT INTO "settings" ("key", "val") VALUES ('qbitCategory', '');
-- PostgreSQL: INSERT INTO settings (key, val) VALUES ('qbitCategory', '');
