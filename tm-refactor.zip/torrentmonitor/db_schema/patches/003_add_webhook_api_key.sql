-- Patch 003: добавление ключа ApiKey в таблицу settings
-- Применяется для установок, обновляющихся со старых версий.
-- Новые установки получают этот ключ автоматически через основные схемы.

-- MySQL / MariaDB:
INSERT IGNORE INTO `settings` (`key`, `val`) VALUES ('ApiKey', '');

-- SQLite:
-- INSERT OR IGNORE INTO "settings" ("key", "val") VALUES ('ApiKey', '');

-- PostgreSQL:
-- INSERT INTO settings ("key", val) VALUES ('ApiKey', '') ON CONFLICT ("key") DO NOTHING;
