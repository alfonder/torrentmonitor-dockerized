<?php
class Sonarr
{
    #выполняем HTTP-запрос к Sonarr API v3 (аутентификация - заголовок X-Api-Key)
    private static function request($host, $apiKey, $method, $path, $body = NULL)
    {
        $options = array(
            CURLOPT_URL            => 'http://'.$host.$path,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => array('X-Api-Key: '.$apiKey, 'Content-Type: application/json'),
            CURLOPT_CUSTOMREQUEST  => $method,
        );
        if ($body !== NULL)
            $options[CURLOPT_POSTFIELDS] = json_encode($body);

        $ch = curl_init();
        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($response === FALSE || $error !== '')
            return array('httpCode' => 0, 'body' => NULL);

        return array('httpCode' => $httpCode, 'body' => json_decode($response, true));
    }

    #"добавляем новую закачку" - на деле сообщаем Sonarr о найденном релизе через
    #POST /api/v3/release/push (тот же механизм, которым Sonarr принимает RSS-релизы от
    #индексеров); Sonarr сам разбирает title, сопоставляет с сериалом/эпизодом и отправляет
    #в свой собственный download-клиент. $file - это URL уже сохранённого .torrent на этом
    #сервере (тот же URL, что для Transmission/qBittorrent/Deluge), поэтому downloadUrl
    #всегда указывает сюда, а не на сам трекер
    public static function addNew($id, $file, $hash, $tracker)
    {
        $settings = Database::getAllSetting();
        foreach ($settings as $row)
        {
            extract($row);
        }

        $torrent = Database::getTorrent($id);
        $name = ( ! empty($torrent[0]['name'])) ? $torrent[0]['name'] : basename($file);

        $body = array(
            'title'       => $name,
            'downloadUrl' => $file,
            'protocol'    => 'torrent',
            'publishDate' => gmdate('c'),
            'indexerId'   => 0,
            'guid'        => 'torrentmonitor-'.$id.'-'.time(),
        );

        $result = self::request($torrentAddress, $torrentPassword, 'POST', '/api/v3/release/push', $body);

        if ($result['httpCode'] == 401 || $result['httpCode'] == 403)
            return array('status' => FALSE, 'msg' => 'log_passwd');
        if ($result['httpCode'] == 0)
            return array('status' => FALSE, 'msg' => 'connect_fail');
        if ($result['httpCode'] != 200 || empty($result['body']) || ! is_array($result['body']))
            return array('status' => FALSE, 'msg' => 'add_fail');

        $release = $result['body'][0];
        if ( ! empty($release['rejected']))
            return array('status' => FALSE, 'msg' => 'add_fail');

        #если Sonarr успел разобрать .torrent и определить infoHash - сохраняем его,
        #чтобы remove() позже мог найти раздачу в очереди; если нет - просто нет hash-привязки
        $hashNew = ( ! empty($release['infoHash'])) ? $release['infoHash'] : '';
        if ( ! empty($hashNew))
            Database::updateHash($id, $hashNew);

        Database::clearWarnings('Sonarr');
        return array('status' => TRUE, 'hash' => $hashNew);
    }

    #удаляем раздачу из очереди Sonarr. DELETE /api/v3/queue/{id} принимает собственный
    #внутренний id записи очереди Sonarr, а не хэш торрента - поэтому сначала ищем нужную
    #запись в GET /api/v3/queue по полю downloadId (это и есть хэш клиента-загрузчика)
    public static function remove($hash)
    {
        if (empty($hash))
            return array('status' => TRUE);

        $settings = Database::getAllSetting();
        foreach ($settings as $row)
        {
            extract($row);
        }

        $result = self::request($torrentAddress, $torrentPassword, 'GET', '/api/v3/queue?pageSize=250&includeUnknownSeriesItems=true');

        if ($result['httpCode'] == 401 || $result['httpCode'] == 403)
            return array('status' => FALSE, 'msg' => 'log_passwd');
        if ($result['httpCode'] == 0)
            return array('status' => FALSE, 'msg' => 'connect_fail');
        if ($result['httpCode'] != 200 || empty($result['body']['records']))
            return array('status' => TRUE); //очередь пуста или недоступна для чтения - нечего удалять

        $queueId = NULL;
        foreach ($result['body']['records'] as $record)
        {
            if ( ! empty($record['downloadId']) && strcasecmp($record['downloadId'], $hash) === 0)
            {
                $queueId = $record['id'];
                break;
            }
        }

        #раздачи уже нет в очереди (импортирована или удалена руками) - это не ошибка
        if ($queueId === NULL)
            return array('status' => TRUE);

        $result = self::request($torrentAddress, $torrentPassword, 'DELETE', '/api/v3/queue/'.$queueId.'?removeFromClient=true&blocklist=false');

        if ($result['httpCode'] == 401 || $result['httpCode'] == 403)
            return array('status' => FALSE, 'msg' => 'log_passwd');
        if ($result['httpCode'] != 200)
            return array('status' => FALSE, 'msg' => 'unknown');

        Database::clearWarnings('Sonarr');
        return array('status' => TRUE);
    }
}
?>
